import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-terms-privacy',
  templateUrl: './terms-privacy.page.html',
  styleUrls: ['./terms-privacy.page.scss'],
})
export class TermsPrivacyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}  
