import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login-host',
  templateUrl: './login-host.page.html',
  styleUrls: ['./login-host.page.scss'],
})
export class LoginHostPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
