import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-feed',
  templateUrl: './live-feed.page.html',
  styleUrls: ['./live-feed.page.scss'],
})
export class LiveFeedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
