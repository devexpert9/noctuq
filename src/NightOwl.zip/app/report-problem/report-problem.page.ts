import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-problem',
  templateUrl: './report-problem.page.html',
  styleUrls: ['./report-problem.page.scss'],
})
export class ReportProblemPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
