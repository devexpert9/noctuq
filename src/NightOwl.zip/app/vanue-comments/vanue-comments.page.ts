import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vanue-comments',
  templateUrl: './vanue-comments.page.html',
  styleUrls: ['./vanue-comments.page.scss'],
})
export class VanueCommentsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
