import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-make-live-feed',
  templateUrl: './make-live-feed.page.html',
  styleUrls: ['./make-live-feed.page.scss'],
})
export class MakeLiveFeedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
